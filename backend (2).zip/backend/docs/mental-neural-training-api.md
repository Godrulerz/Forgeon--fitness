# Mental Neural Training API Documentation

## Overview

The Mental Neural Training API provides comprehensive functionality for managing cognitive training drills, sessions, and analytics. It integrates with Python scripts for drill execution and automatically pushes data to the analytics system.

## Base URL

```
http://localhost:3000/api/mental-neural-training
```

## Authentication

All endpoints require authentication. Include the authorization header:
```
Authorization: Bearer <your-token>
```

## Models

### Drill Schema
```javascript
{
  _id: ObjectId,
  name: String (required),
  category: String (enum: ['reaction', 'focus', 'coordination', 'memory', 'dual_task', 'attention', 'processing_speed']),
  description: String,
  difficulty: String (enum: ['beginner', 'intermediate', 'advanced']),
  estimatedDuration: Number, // in seconds
  equipmentRequired: [String],
  instructions: String,
  config: {
    duration: Number,
    trials: Number,
    restBetweenTrials: Number,
    difficulty: String,
    audioEnabled: Boolean,
    visualCues: Boolean,
    stimulusDelay: Number,
    responseTimeout: Number,
    targetAccuracy: Number,
    targetReactionTime: Number
  },
  parameters: Object,
  createdBy: String,
  isActive: Boolean,
  tags: [String],
  normativeData: {
    beginner: { avgReactionTime: Number, accuracy: Number, completionTime: Number },
    intermediate: { avgReactionTime: Number, accuracy: Number, completionTime: Number },
    advanced: { avgReactionTime: Number, accuracy: Number, completionTime: Number }
  },
  createdAt: Date,
  updatedAt: Date
}
```

### Session Schema
```javascript
{
  _id: ObjectId,
  athleteId: String (required),
  drillId: ObjectId (ref: 'MN_Drill'),
  coachId: String,
  startedAt: Date,
  endedAt: Date,
  settings: Object,
  results: [{
    trial: Number,
    reactionTime: Number,
    accuracy: Boolean,
    timestamp: Date,
    stimulusType: String,
    responseType: String,
    difficulty: String,
    notes: String
  }],
  metrics: {
    avgReactionTime: Number,
    bestReactionTime: Number,
    worstReactionTime: Number,
    accuracy: Number,
    successRate: Number,
    trialsCompleted: Number,
    totalTrials: Number,
    completionTime: Number,
    score: Number,
    consistencyScore: Number,
    improvementRate: Number
  },
  performance: {
    percentile: Number,
    rating: String,
    trend: String
  },
  notes: String,
  status: String (enum: ['scheduled', 'in_progress', 'completed', 'cancelled', 'paused']),
  baselineComparison: {
    previousSessionId: ObjectId,
    improvement: Number,
    trend: String
  },
  createdAt: Date,
  updatedAt: Date
}
```

## Endpoints

### Drills

#### GET /drills
Get all active drills with optional filtering.

**Query Parameters:**
- `category` (optional): Filter by drill category
- `difficulty` (optional): Filter by difficulty level

**Response:**
```javascript
[
  {
    "_id": "507f1f77bcf86cd799439011",
    "name": "Visual Reaction Test",
    "category": "reaction",
    "description": "Test visual reaction time with color changes",
    "difficulty": "beginner",
    "estimatedDuration": 300,
    "equipmentRequired": ["computer", "keyboard"],
    "instructions": "Press the spacebar as quickly as possible when the screen changes color",
    "config": {
      "duration": 300,
      "trials": 10,
      "restBetweenTrials": 3,
      "difficulty": "beginner",
      "audioEnabled": false,
      "visualCues": true,
      "stimulusDelay": 2000,
      "responseTimeout": 2000,
      "targetAccuracy": 80,
      "targetReactionTime": 500
    },
    "tags": ["reaction", "visual", "beginner"],
    "isActive": true,
    "createdAt": "2024-12-20T10:00:00.000Z",
    "updatedAt": "2024-12-20T10:00:00.000Z"
  }
]
```

#### POST /drills
Create a new drill.

**Request Body:**
```javascript
{
  "name": "New Reaction Drill",
  "category": "reaction",
  "description": "A new reaction time drill",
  "difficulty": "intermediate",
  "estimatedDuration": 240,
  "equipmentRequired": ["computer", "keyboard"],
  "instructions": "Follow the on-screen instructions",
  "config": {
    "duration": 240,
    "trials": 8,
    "restBetweenTrials": 4,
    "difficulty": "intermediate",
    "audioEnabled": true,
    "visualCues": true,
    "stimulusDelay": 1500,
    "responseTimeout": 1500,
    "targetAccuracy": 85,
    "targetReactionTime": 400
  },
  "tags": ["reaction", "intermediate"]
}
```

#### GET /drills/:id
Get a specific drill by ID.

**Response:**
```javascript
{
  "_id": "507f1f77bcf86cd799439011",
  "name": "Visual Reaction Test",
  "category": "reaction",
  "description": "Test visual reaction time with color changes",
  "difficulty": "beginner",
  "estimatedDuration": 300,
  "equipmentRequired": ["computer", "keyboard"],
  "instructions": "Press the spacebar as quickly as possible when the screen changes color",
  "config": {
    "duration": 300,
    "trials": 10,
    "restBetweenTrials": 3,
    "difficulty": "beginner",
    "audioEnabled": false,
    "visualCues": true,
    "stimulusDelay": 2000,
    "responseTimeout": 2000,
    "targetAccuracy": 80,
    "targetReactionTime": 500
  },
  "tags": ["reaction", "visual", "beginner"],
  "normativeData": {
    "beginner": {
      "avgReactionTime": 600,
      "accuracy": 70,
      "completionTime": 300
    },
    "intermediate": {
      "avgReactionTime": 450,
      "accuracy": 80,
      "completionTime": 250
    },
    "advanced": {
      "avgReactionTime": 350,
      "accuracy": 90,
      "completionTime": 200
    }
  },
  "isActive": true,
  "createdAt": "2024-12-20T10:00:00.000Z",
  "updatedAt": "2024-12-20T10:00:00.000Z"
}
```

#### PUT /drills/:id
Update an existing drill.

**Request Body:** Same as POST /drills

#### DELETE /drills/:id
Deactivate a drill (soft delete).

**Response:**
```javascript
{
  "message": "Drill deactivated successfully"
}
```

### Sessions

#### GET /sessions
Get all sessions with optional filtering.

**Query Parameters:**
- `athleteId` (optional): Filter by athlete ID
- `drillId` (optional): Filter by drill ID
- `status` (optional): Filter by session status

**Response:**
```javascript
[
  {
    "_id": "507f1f77bcf86cd799439012",
    "athleteId": "athlete-1",
    "drillId": {
      "_id": "507f1f77bcf86cd799439011",
      "name": "Visual Reaction Test",
      "category": "reaction"
    },
    "coachId": "coach-1",
    "startedAt": "2024-12-15T10:00:00.000Z",
    "endedAt": "2024-12-15T10:05:00.000Z",
    "settings": {
      "duration": 300,
      "trials": 10,
      "restBetweenTrials": 3,
      "difficulty": "beginner",
      "audioEnabled": false,
      "visualCues": true,
      "stimulusDelay": 2000,
      "responseTimeout": 2000,
      "targetAccuracy": 80,
      "targetReactionTime": 500
    },
    "results": [
      {
        "trial": 1,
        "reactionTime": 450,
        "accuracy": true,
        "timestamp": "2024-12-15T10:00:30.000Z",
        "stimulusType": "visual",
        "responseType": "correct",
        "difficulty": "medium"
      }
    ],
    "metrics": {
      "avgReactionTime": 462,
      "bestReactionTime": 350,
      "worstReactionTime": 600,
      "accuracy": 90,
      "successRate": 80,
      "trialsCompleted": 10,
      "totalTrials": 10,
      "completionTime": 300,
      "score": 82,
      "consistencyScore": 85,
      "improvementRate": null
    },
    "performance": {
      "percentile": 75,
      "rating": "good",
      "trend": "stable"
    },
    "status": "completed",
    "notes": "Good performance, consistent reaction times",
    "createdAt": "2024-12-15T10:00:00.000Z",
    "updatedAt": "2024-12-15T10:05:00.000Z"
  }
]
```

#### POST /sessions
Create a new session.

**Request Body:**
```javascript
{
  "athleteId": "athlete-1",
  "drillId": "507f1f77bcf86cd799439011",
  "coachId": "coach-1",
  "status": "scheduled"
}
```

#### GET /sessions/:id
Get a specific session by ID.

#### PUT /sessions/:id
Update an existing session.

#### DELETE /sessions/:id
Delete a session.

### Session Execution

#### POST /sessions/:sessionId/start
Start a scheduled session.

**Response:**
```javascript
{
  "_id": "507f1f77bcf86cd799439012",
  "status": "in_progress",
  "startedAt": "2024-12-20T10:00:00.000Z",
  // ... other session data
}
```

#### POST /sessions/:sessionId/complete
Complete a session with results.

**Request Body:**
```javascript
{
  "results": [
    {
      "trial": 1,
      "reactionTime": 450,
      "accuracy": true,
      "timestamp": "2024-12-20T10:00:30.000Z",
      "stimulusType": "visual",
      "responseType": "correct",
      "difficulty": "medium"
    },
    {
      "trial": 2,
      "reactionTime": 520,
      "accuracy": true,
      "timestamp": "2024-12-20T10:00:45.000Z",
      "stimulusType": "visual",
      "responseType": "correct",
      "difficulty": "medium"
    }
  ]
}
```

**Response:** Updated session with calculated metrics

### Python Script Integration

#### POST /execute-drill
Execute a drill using the Python script.

**Request Body:**
```javascript
{
  "drillId": "507f1f77bcf86cd799439011",
  "athleteId": "athlete-1",
  "duration": 30
}
```

**Response:**
```javascript
{
  "session": {
    "_id": "507f1f77bcf86cd799439013",
    "athleteId": "athlete-1",
    "drillId": "507f1f77bcf86cd799439011",
    "status": "completed",
    "startedAt": "2024-12-20T10:00:00.000Z",
    "endedAt": "2024-12-20T10:00:30.000Z",
    "results": [
      {
        "trial": 1,
        "reactionTime": 450,
        "accuracy": true,
        "timestamp": "2024-12-20T10:00:05.000Z",
        "stimulusType": "visual",
        "responseType": "correct",
        "difficulty": "medium"
      }
    ],
    "metrics": {
      "avgReactionTime": 450,
      "bestReactionTime": 450,
      "worstReactionTime": 450,
      "accuracy": 100,
      "successRate": 100,
      "trialsCompleted": 1,
      "totalTrials": 1,
      "completionTime": 30,
      "score": 100,
      "consistencyScore": 100
    }
  },
  "pythonOutput": "Starting drill 'Visual Reaction Test'\n🔹 Trial 1/10: Wait for stimulus...\n⚡ Stimulus appeared! TAP NOW (press Enter)\nReaction Time: 450ms\n✅ Drill completed.\n📊 Results Summary: { avg_reaction_time: 450, best_time: 450, success_rate: 100, trials_completed: 1, score: 100 }",
  "summary": {
    "avgReactionTime": 450,
    "bestReactionTime": 450,
    "worstReactionTime": 450,
    "accuracy": 100,
    "successRate": 100,
    "trialsCompleted": 1,
    "totalTrials": 1,
    "completionTime": 30,
    "score": 100,
    "consistencyScore": 100
  }
}
```

### Analytics

#### GET /analytics/athlete/:athleteId
Get analytics for a specific athlete.

**Query Parameters:**
- `period` (optional): Time period (week, month, quarter, year)
- `category` (optional): Filter by category

**Response:**
```javascript
[
  {
    "_id": "507f1f77bcf86cd799439014",
    "athleteId": "athlete-1",
    "period": "month",
    "startDate": "2024-12-01T00:00:00.000Z",
    "endDate": "2024-12-31T23:59:59.000Z",
    "category": "overall",
    "metrics": {
      "avgReactionTime": 435,
      "bestReactionTime": 350,
      "accuracy": 90,
      "consistencyScore": 85,
      "improvementRate": 12,
      "sessionsCompleted": 2,
      "totalDrills": 2
    },
    "trends": {
      "reactionTime": "improving",
      "accuracy": "improving",
      "consistency": "stable",
      "overallTrend": "improving"
    },
    "recommendations": [
      {
        "category": "reaction_time",
        "title": "Continue Reaction Training",
        "description": "Your reaction times are improving well. Keep up the good work!",
        "priority": "medium",
        "actionItems": [
          "Continue with current training frequency",
          "Try more advanced drills",
          "Focus on consistency"
        ]
      }
    ],
    "sessionIds": ["507f1f77bcf86cd799439012", "507f1f77bcf86cd799439013"],
    "createdAt": "2024-12-20T10:00:00.000Z",
    "updatedAt": "2024-12-20T10:00:00.000Z"
  }
]
```

#### POST /analytics/generate
Generate comprehensive analytics for a time period.

**Request Body:**
```javascript
{
  "athleteId": "athlete-1",
  "period": "month",
  "startDate": "2024-12-01T00:00:00.000Z",
  "endDate": "2024-12-31T23:59:59.000Z"
}
```

#### GET /analytics/trends/:athleteId
Get performance trends for an athlete.

**Query Parameters:**
- `days` (optional): Number of days to analyze (default: 30)

**Response:**
```javascript
{
  "reactionTime": "improving",
  "accuracy": "improving",
  "consistency": "stable",
  "overallTrend": "improving",
  "improvementRate": 12
}
```

#### GET /analytics/report/:athleteId
Get comprehensive analytics report combining mental neural training and general analytics.

**Query Parameters:**
- `period` (optional): Time period (default: month)

**Response:**
```javascript
{
  "athleteId": "athlete-1",
  "period": "month",
  "mentalNeuralTraining": [
    // Mental neural training analytics
  ],
  "generalAnalytics": [
    // General analytics data
  ],
  "summary": {
    "totalSessions": 2,
    "avgReactionTime": 435,
    "avgAccuracy": 90,
    "overallTrend": "improving"
  }
}
```

### Dashboard Statistics

#### GET /dashboard/:athleteId
Get dashboard statistics for an athlete.

**Query Parameters:**
- `days` (optional): Number of days to analyze (default: 30)

**Response:**
```javascript
{
  "totalSessions": 2,
  "totalDrills": 2,
  "avgReactionTime": 435,
  "avgAccuracy": 90,
  "bestScore": 100,
  "recentTrend": "improving",
  "categoryBreakdown": {
    "reaction": {
      "count": 2,
      "avgScore": 91,
      "totalScore": 182
    }
  }
}
```

## Error Responses

### 400 Bad Request
```javascript
{
  "message": "Validation error",
  "errors": [
    {
      "field": "name",
      "message": "Name is required"
    }
  ]
}
```

### 404 Not Found
```javascript
{
  "message": "Drill not found"
}
```

### 500 Internal Server Error
```javascript
{
  "message": "Internal server error",
  "error": "Error details"
}
```

## Analytics Integration

The Mental Neural Training API automatically integrates with the main analytics system:

1. **Automatic Data Push**: When sessions are completed, data is automatically pushed to the analytics system
2. **Performance Tracking**: All performance metrics are tracked and stored for trend analysis
3. **Recommendations**: AI-powered recommendations are generated based on performance data
4. **Comprehensive Reports**: Combined reports include both mental neural training and general analytics data

## Python Script Integration

The API integrates with the Python script (`script.py`) for drill execution:

1. **Script Execution**: The API can execute the Python script with parameters
2. **Output Parsing**: Python script output is parsed to extract results
3. **Session Creation**: Results are automatically stored in session records
4. **Analytics Generation**: Analytics are generated from the Python script results

## Usage Examples

### Complete Workflow Example

1. **Create a Drill**
```bash
curl -X POST http://localhost:3000/api/mental-neural-training/drills \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "name": "Custom Reaction Test",
    "category": "reaction",
    "description": "Custom reaction time test",
    "difficulty": "intermediate",
    "estimatedDuration": 300,
    "equipmentRequired": ["computer", "keyboard"],
    "instructions": "Press spacebar when you see the stimulus",
    "config": {
      "duration": 300,
      "trials": 10,
      "restBetweenTrials": 3,
      "difficulty": "intermediate",
      "audioEnabled": false,
      "visualCues": true,
      "stimulusDelay": 2000,
      "responseTimeout": 2000,
      "targetAccuracy": 80,
      "targetReactionTime": 500
    }
  }'
```

2. **Create a Session**
```bash
curl -X POST http://localhost:3000/api/mental-neural-training/sessions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "athleteId": "athlete-1",
    "drillId": "507f1f77bcf86cd799439011",
    "coachId": "coach-1",
    "status": "scheduled"
  }'
```

3. **Execute Drill with Python Script**
```bash
curl -X POST http://localhost:3000/api/mental-neural-training/execute-drill \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "drillId": "507f1f77bcf86cd799439011",
    "athleteId": "athlete-1",
    "duration": 30
  }'
```

4. **Get Analytics**
```bash
curl -X GET "http://localhost:3000/api/mental-neural-training/analytics/athlete/athlete-1?period=month" \
  -H "Authorization: Bearer <token>"
```

5. **Get Dashboard Statistics**
```bash
curl -X GET "http://localhost:3000/api/mental-neural-training/dashboard/athlete-1?days=30" \
  -H "Authorization: Bearer <token>"
```

## Performance Metrics

The system tracks the following performance metrics:

- **Reaction Time**: Average, best, and worst reaction times
- **Accuracy**: Percentage of correct responses
- **Success Rate**: Percentage of responses under target time
- **Consistency Score**: Measure of performance consistency (0-100)
- **Overall Score**: Weighted combination of accuracy, reaction time, and consistency
- **Performance Rating**: Excellent, Good, Average, Below Average, Poor
- **Percentile**: Performance compared to normative data
- **Trends**: Improving, Declining, or Stable performance

## Recommendations System

The API automatically generates recommendations based on performance:

- **Reaction Time**: Suggestions for improving speed
- **Accuracy**: Focus on precision training
- **Consistency**: Recommendations for regular training
- **Frequency**: Suggestions for optimal training schedule

## Data Flow

1. **Drill Creation** → Drill stored in database
2. **Session Creation** → Session scheduled
3. **Session Execution** → Python script runs → Results collected
4. **Session Completion** → Metrics calculated → Analytics generated
5. **Analytics Push** → Data pushed to main analytics system
6. **Report Generation** → Comprehensive reports available

This creates a complete cycle from drill creation to analytics reporting with full integration between all components.
