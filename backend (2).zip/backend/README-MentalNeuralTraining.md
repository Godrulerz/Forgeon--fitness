# Mental Neural Training Module

## Overview

The Mental Neural Training module is a comprehensive cognitive training system that provides drill management, session execution, performance tracking, and analytics integration. It seamlessly integrates with Python scripts for drill execution and automatically pushes data to the analytics system for complete reporting.

## Features

### 🧠 Cognitive Training Drills
- **Multiple Categories**: Reaction, Focus, Coordination, Memory, Dual-Task, Attention, Processing Speed
- **Difficulty Levels**: Beginner, Intermediate, Advanced
- **Configurable Parameters**: Duration, trials, rest periods, stimulus types, response timeouts
- **Normative Data**: Performance benchmarks for each difficulty level

### 📊 Session Management
- **Session Lifecycle**: Scheduled → In Progress → Completed/Cancelled
- **Real-time Execution**: Start, pause, and complete sessions
- **Result Tracking**: Individual trial results with timestamps
- **Performance Metrics**: Automatic calculation of reaction times, accuracy, consistency

### 🔄 Python Script Integration
- **Seamless Execution**: Direct integration with Python scripts
- **Parameter Passing**: Dynamic configuration for drill execution
- **Output Parsing**: Automatic extraction of results from Python output
- **Error Handling**: Graceful handling of script execution failures

### 📈 Analytics & Reporting
- **Automatic Data Push**: Session completion triggers analytics generation
- **Performance Trends**: Track improvement over time
- **Recommendations**: AI-powered suggestions based on performance
- **Comprehensive Reports**: Combined mental neural training and general analytics

### 🎯 Performance Metrics
- **Reaction Time**: Average, best, and worst times
- **Accuracy**: Percentage of correct responses
- **Consistency Score**: Performance stability measurement
- **Overall Score**: Weighted combination of all metrics
- **Performance Rating**: Excellent, Good, Average, Below Average, Poor

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend API    │    │   Python Script │
│   (React)       │◄──►│   (Node.js)      │◄──►│   (script.py)   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                              │
                              ▼
                       ┌──────────────────┐
                       │   MongoDB        │
                       │   Database       │
                       └──────────────────┘
                              │
                              ▼
                       ┌──────────────────┐
                       │   Analytics      │
                       │   System         │
                       └──────────────────┘
```

## Database Models

### Drill Model
```javascript
{
  name: String,
  category: String, // reaction, focus, coordination, memory, dual_task, attention, processing_speed
  description: String,
  difficulty: String, // beginner, intermediate, advanced
  estimatedDuration: Number,
  equipmentRequired: [String],
  instructions: String,
  config: {
    duration: Number,
    trials: Number,
    restBetweenTrials: Number,
    difficulty: String,
    audioEnabled: Boolean,
    visualCues: Boolean,
    stimulusDelay: Number,
    responseTimeout: Number,
    targetAccuracy: Number,
    targetReactionTime: Number
  },
  normativeData: {
    beginner: { avgReactionTime: Number, accuracy: Number, completionTime: Number },
    intermediate: { avgReactionTime: Number, accuracy: Number, completionTime: Number },
    advanced: { avgReactionTime: Number, accuracy: Number, completionTime: Number }
  }
}
```

### Session Model
```javascript
{
  athleteId: String,
  drillId: ObjectId,
  coachId: String,
  startedAt: Date,
  endedAt: Date,
  settings: Object,
  results: [{
    trial: Number,
    reactionTime: Number,
    accuracy: Boolean,
    timestamp: Date,
    stimulusType: String,
    responseType: String,
    difficulty: String
  }],
  metrics: {
    avgReactionTime: Number,
    bestReactionTime: Number,
    worstReactionTime: Number,
    accuracy: Number,
    successRate: Number,
    trialsCompleted: Number,
    completionTime: Number,
    score: Number,
    consistencyScore: Number
  },
  performance: {
    percentile: Number,
    rating: String,
    trend: String
  }
}
```

### Analytics Model
```javascript
{
  athleteId: String,
  period: String, // week, month, quarter, year
  startDate: Date,
  endDate: Date,
  category: String,
  metrics: {
    avgReactionTime: Number,
    bestReactionTime: Number,
    accuracy: Number,
    consistencyScore: Number,
    improvementRate: Number,
    sessionsCompleted: Number,
    totalDrills: Number
  },
  trends: {
    reactionTime: String, // improving, declining, stable
    accuracy: String,
    consistency: String,
    overallTrend: String
  },
  recommendations: [{
    category: String,
    title: String,
    description: String,
    priority: String, // high, medium, low
    actionItems: [String]
  }]
}
```

## API Endpoints

### Drills
- `GET /drills` - List all drills with filtering
- `POST /drills` - Create new drill
- `GET /drills/:id` - Get specific drill
- `PUT /drills/:id` - Update drill
- `DELETE /drills/:id` - Deactivate drill

### Sessions
- `GET /sessions` - List all sessions with filtering
- `POST /sessions` - Create new session
- `GET /sessions/:id` - Get specific session
- `PUT /sessions/:id` - Update session
- `DELETE /sessions/:id` - Delete session

### Session Execution
- `POST /sessions/:sessionId/start` - Start a session
- `POST /sessions/:sessionId/complete` - Complete session with results

### Python Integration
- `POST /execute-drill` - Execute drill using Python script

### Analytics
- `GET /analytics/athlete/:athleteId` - Get athlete analytics
- `POST /analytics/generate` - Generate comprehensive analytics
- `GET /analytics/trends/:athleteId` - Get performance trends
- `GET /analytics/report/:athleteId` - Get comprehensive report

### Dashboard
- `GET /dashboard/:athleteId` - Get dashboard statistics

## Setup Instructions

### 1. Prerequisites
- Node.js (v14 or higher)
- MongoDB
- Python 3.7+ (for script execution)
- Required Python packages (if any)

### 2. Installation
```bash
# Navigate to backend directory
cd project/backend

# Install dependencies
npm install

# Set up environment variables
cp env.example .env
# Edit .env with your MongoDB connection string and other settings
```

### 3. Database Setup
```bash
# The models will be automatically created when the application starts
# You can also seed the database with sample data:
node -e "require('./src/utils/seedMentalNeuralTraining').seedMentalNeuralTraining()"
```

### 4. Start the Server
```bash
npm start
# or for development
npm run dev
```

## Usage Examples

### 1. Create a Drill
```javascript
const drill = {
  name: "Visual Reaction Test",
  category: "reaction",
  description: "Test visual reaction time with color changes",
  difficulty: "beginner",
  estimatedDuration: 300,
  equipmentRequired: ["computer", "keyboard"],
  instructions: "Press the spacebar as quickly as possible when the screen changes color",
  config: {
    duration: 300,
    trials: 10,
    restBetweenTrials: 3,
    difficulty: "beginner",
    audioEnabled: false,
    visualCues: true,
    stimulusDelay: 2000,
    responseTimeout: 2000,
    targetAccuracy: 80,
    targetReactionTime: 500
  }
};

const response = await fetch('/api/mental-neural-training/drills', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(drill)
});
```

### 2. Execute a Drill with Python Script
```javascript
const execution = {
  drillId: "507f1f77bcf86cd799439011",
  athleteId: "athlete-1",
  duration: 30
};

const response = await fetch('/api/mental-neural-training/execute-drill', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(execution)
});

const result = await response.json();
console.log('Session metrics:', result.session.metrics);
console.log('Python output:', result.pythonOutput);
```

### 3. Get Analytics
```javascript
const analytics = await fetch('/api/mental-neural-training/analytics/athlete/athlete-1?period=month');
const data = await analytics.json();
console.log('Analytics:', data);
```

## Python Script Integration

The module integrates with the Python script (`script.py`) located in `src/MentalNeuralTraining/`. The script provides:

- **Drill Execution**: Runs cognitive training drills
- **Result Collection**: Captures reaction times and accuracy
- **Output Formatting**: Structured output for API parsing

### Script Features
- Configurable trial parameters
- Random stimulus delays
- Response time measurement
- Accuracy tracking
- Session management

### Integration Points
1. **Parameter Passing**: API passes drill configuration to Python script
2. **Execution Control**: API manages script execution lifecycle
3. **Output Parsing**: API extracts results from script output
4. **Error Handling**: Graceful handling of script failures

## Analytics Integration

The module automatically integrates with the main analytics system:

### Automatic Data Push
- Session completion triggers analytics generation
- Performance metrics are calculated and stored
- Data is pushed to the main analytics collection

### Performance Tracking
- Reaction time trends
- Accuracy improvements
- Consistency measurements
- Overall performance scores

### Recommendations Engine
- AI-powered suggestions based on performance
- Personalized training recommendations
- Progress tracking and goal setting

## Testing

### Run API Tests
```bash
# Install test dependencies
npm install axios

# Run the test suite
node test-mental-neural-training.js
```

### Test Individual Components
```javascript
const { testDrills, testSessions, testAnalytics } = require('./test-mental-neural-training');

// Test specific functionality
await testDrills();
await testSessions(drillId);
await testAnalytics('athlete-1');
```

## Performance Metrics

### Calculation Methods
- **Average Reaction Time**: Mean of all valid responses
- **Accuracy**: Percentage of correct responses
- **Success Rate**: Percentage of responses under target time
- **Consistency Score**: Based on standard deviation of reaction times
- **Overall Score**: Weighted combination (40% accuracy + 40% reaction time + 20% consistency)

### Performance Ratings
- **Excellent**: Score ≥ 90
- **Good**: Score ≥ 80
- **Average**: Score ≥ 70
- **Below Average**: Score ≥ 60
- **Poor**: Score < 60

## Error Handling

### Common Error Scenarios
- **Python Script Errors**: Graceful fallback with error logging
- **Database Connection Issues**: Retry mechanisms and error reporting
- **Invalid Data**: Validation middleware with detailed error messages
- **Authentication Failures**: Proper HTTP status codes and error responses

### Error Response Format
```javascript
{
  "message": "Error description",
  "error": "Detailed error information",
  "timestamp": "2024-12-20T10:00:00.000Z"
}
```

## Security Considerations

### Authentication
- All endpoints require valid authentication tokens
- Token validation middleware
- Role-based access control (if implemented)

### Data Validation
- Input validation for all endpoints
- Schema validation for database operations
- Sanitization of user inputs

### Error Information
- Limited error details in production
- Comprehensive logging for debugging
- Secure error handling

## Monitoring and Logging

### Performance Monitoring
- Request/response timing
- Database query performance
- Python script execution time
- Memory usage tracking

### Error Logging
- Detailed error logs with stack traces
- Python script execution logs
- Database operation logs
- API request/response logs

## Future Enhancements

### Planned Features
- **Real-time WebSocket Support**: Live session monitoring
- **Advanced Analytics**: Machine learning-based insights
- **Mobile App Integration**: Native mobile drill execution
- **Multi-player Support**: Competitive training sessions
- **Custom Drill Builder**: Visual drill configuration interface

### Performance Optimizations
- **Caching**: Redis integration for frequently accessed data
- **Database Indexing**: Optimized queries for large datasets
- **Background Processing**: Async analytics generation
- **CDN Integration**: Static asset delivery optimization

## Contributing

### Development Setup
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

### Code Standards
- Follow ESLint configuration
- Use meaningful commit messages
- Add JSDoc comments for functions
- Maintain test coverage

## Support

### Documentation
- API documentation: `docs/mental-neural-training-api.md`
- Database schema documentation
- Python script documentation

### Troubleshooting
- Check server logs for error details
- Verify Python script permissions
- Ensure MongoDB connection
- Validate authentication tokens

### Contact
For support and questions, please refer to the main project documentation or create an issue in the repository.

---

**Note**: This module is part of the larger ForgeOn Fitness Assessment Platform and integrates seamlessly with other modules for comprehensive athlete performance tracking and analytics.
